# NodeJs Server Side Form Validation using Express Validator

This was created as part of YouTube Video. Links below

![GitHub Logo](https://raddy.co.uk/wp-content/uploads/2020/08/nodejs-express-validator-body-parser_compressed.jpg)


### YouTube Video & Article

[NodeJs Server Side Form Validation](https://www.youtube.com/watch?v=z8m_Vy_9FIs)

[Read Article](https://raddy.co.uk/blog/node-js-form-validation-using-express-validator-and-ejs/)

### YouTube Channel - RaddyTheBrand

[Subscribe to my YouTube Channel](https://www.youtube.com/channel/UCvXscyQ0cLzPZeNOeXI45Sw?sub_confirmation=1)

### Website
[www.raddy.co.uk](https://www.raddy.co.uk)

### Donations
[Via Paypal](https://www.paypal.me/RadoslavAngelov)

[Buy me a Coffee](https://www.buymeacoffee.com/RaddyTheBrand)
